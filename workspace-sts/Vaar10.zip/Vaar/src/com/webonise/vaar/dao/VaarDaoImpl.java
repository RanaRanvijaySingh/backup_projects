package com.webonise.vaar.dao;

import java.io.IOException;
import java.util.List;
import javax.swing.JOptionPane;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;

public class VaarDaoImpl implements VaarDao {

	@Autowired
	SessionFactory sessionfactory;

	@Override
	public String search(String query) {
		
		System.out.println("\n\nDAO : In the search function.");
		List<?> list = sessionfactory.getCurrentSession().createQuery(query).list();
		
		System.out.println("DAO : Query made to database .");
		
		String json = "[";
		for (int i = 0; i < list.size(); i++) {
			ObjectWriter ow = new ObjectMapper().writer()
					.withDefaultPrettyPrinter();
			try {
				if (i != 0)
					json += ",";
				json += ow.writeValueAsString(list.get(i));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		json+="]";
		if (list.size() == 0)
			JOptionPane.showMessageDialog(null, "No Records Found !!!");
		
		System.out.println("DAO : JSON returned is a String : ");
		System.out.println("DAO : "+ json);
		
		
		return json;
	}
}
