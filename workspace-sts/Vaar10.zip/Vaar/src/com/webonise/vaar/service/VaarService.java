package com.webonise.vaar.service;


public interface VaarService {
	
	public String search(java.util.List<String> parameters,String classpath);

}
