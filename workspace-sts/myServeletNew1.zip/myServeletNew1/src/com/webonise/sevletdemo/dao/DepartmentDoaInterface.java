package com.webonise.sevletdemo.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.webonise.serveletdemo.model.Department;

/**
 * @author webonise
 * interface to be implemented by the DepartmentImp class
 */
public interface DepartmentDoaInterface 
{
	void addDepartmentRow(Department department) throws SQLException;
	public ArrayList<Department> fetchDaoDepartmentData() throws SQLException;

}
