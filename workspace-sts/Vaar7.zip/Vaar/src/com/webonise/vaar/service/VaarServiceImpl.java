package com.webonise.vaar.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import com.webonise.vaar.dao.VaarDao;
import com.webonise.vaar.dao.VaarDaoImpl;



public class VaarServiceImpl implements VaarService{
	
	@Autowired
	VaarServiceHelper vaarServiceHelper;
	
	@Autowired
	VaarDao vaarDao;

	@Override
	public List search(java.util.List<String> parameters, String classpath) {
		// TODO Auto-generated method stub

		System.out.println("\n\nIn the Service ...");
		
		String query;
		List list=null;
		
		
			try 
			{
				query = vaarServiceHelper.generateQuery(parameters,classpath);
				System.out.print("query : \t"+query);
				
				//VaarDao vaarDao=new VaarDaoImpl(classpath);
				
				//......................new added method to use SPRING............
				System.out.print("setting the class path in DAO layer...");
				vaarDao.setClassPath(classpath);
				System.out.print("classpath set... ");
				
				System.out.print("calling the search function of DAO.");
				list=vaarDao.search(query);
				System.out.println("list received ...");
				System.out.println(list);
				
				return list;
			}
			catch (ClassNotFoundException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return list;
		
		
		
	}
}
