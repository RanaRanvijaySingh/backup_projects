/**
 * 
 */
package com.webonise.vaar.controller;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.webonise.vaar.service.VaarService;

/**
 * @author Vijayraj Nathe
 *
 */
@Controller
public class VaarController {
	
	@Autowired
	private VaarService service;

	@RequestMapping(value="/fetcher",method=RequestMethod.GET)
 public String  call(@RequestParam("parameters")String name)
 {
		System.out.println("\n\nIn the controller...");
	String arr[]=name.split(",");
	String classpath=null;
    List<String> parameters=new ArrayList<String>();
    List list;
    for (int i = 0; i < arr.length; i+=2) {
		String parameter = arr[i];
		if(parameter.equals("definition"))
			classpath=arr[i+1];
		else
		if(!arr[i+1].equals("?")){
			   parameters.add(parameter);
    		   parameters.add(arr[i+1]);
		}
	}
    JOptionPane.showMessageDialog(null, parameters);
    
	System.out.println("parameter :\t"+parameters + "\nclasspath :\t" +classpath);
	
    list=service.search(parameters,classpath);
	
    return "";
 }
}
