package com.webonise.vaar.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.webonise.vaar.dao.VaarDao;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class VaarServiceImpl implements VaarService {

	@Autowired
	VaarServiceHelper vaarServiceHelper;
	
	@Autowired
	VaarDao vaarDao;
	
	@Override
	public String search(java.util.List<String> parameters, String classpath) {
		// TODO Auto-generated method stub
		
		System.out.println("\n\nSERVICE : In the search function.");
		String query;
		String json = null;

		try 
		{
			
			query = vaarServiceHelper.generateQuery(parameters, classpath);
			System.out.println("\n\nSERVICE : Calling Dao layer.");
			json = vaarDao.search(query);
		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return json;

	}
}
