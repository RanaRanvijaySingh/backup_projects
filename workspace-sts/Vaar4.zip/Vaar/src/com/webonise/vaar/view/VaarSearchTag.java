package com.webonise.vaar.view;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyTagSupport;

import org.springframework.beans.factory.annotation.Autowired;


import com.webonise.vaar.utility.AnnotationResolver;

/**
 * @author Anvay Rajhansa This class is to manage the custom tag MySearch
 * 
 */

//@ContextConfiguration(locations = {"/WEB-INF/vaar-context.xml"})
public class VaarSearchTag extends BodyTagSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String definition;

	//@Autowired
	private  AnnotationResolver annotationResolver= new AnnotationResolver();

	
	/**
	 * @return the definition
	 */
	public String getDefinition() 
	{
		
		return definition;
	}

	/**
	 * @param definition
	 *            the definition to set definition given in attribute
	 */
	public void setDefinition(String definition) {
		this.definition = definition;
	}
	
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.jsp.tagext.BodyTagSupport#doStartTag()
	 */
	public int doStartTag() throws JspException {


		//Field[] fields =annotationResolver.getFields(definition);
		
		try {
			pageContext.forward("SearchTool.jsp?annotation=\""+ annotationResolver +"\"&defination=\""+ definition +"\"");
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//JspWriter out = pageContext.getOut();
		//Field[] fields =annotationResolver.getFields(definition);
		

		/*try {
			if (fields == null)
				out.println("No attributes !!!");
			else {
				out.println("<form action=\"vaarcontext?def=defination\" method=\"GET\">");
				out.println("<input type=\"hidden\" name=\"defination\" value=\""+definition+"\">");
				out.println("<div style=\"border:2px solid black; float:left; margin:0px 20px 0px 0px; padding:5px \">");
				out.print("<table border=\"2px solid black\">");
				for (Field field : fields) {

					Annotation an[] = field.getAnnotations();
					if (an.length == 0)
						System.out.println("No Annotations !!!");

					for (Annotation annotation : an) {

						if (annotation
								.toString()
								.equals("@com.webonise.vaar.annotationinterface.SearchColumn()")) {
							out.print("<tr>");
							out.print("<td>");
							out.println("<label>" + field.getName()
									+ "</label> </td><td>");

							out.println("<input type=\"text\" name=\""+field.getName()+"\"\"> </br>");
							out.print("</td>");
							out.print("</tr>");
						}
					}
				}
				out.print("<tr>");
				out.print("<td colspan=\"2\" align=\"center\">");
				out.println("<input type=\"submit\" value=\"Search\">");
				out.print("</td>");
				out.print("</tr>");
				out.print("</table>");
				out.println("</div>");
                out.println("</form>");
				out.println("<div style=\"border:2px solid black; float:left; padding:5px;\">");
				out.print("<table>");
				out.print("<tr>");
				for (Field field1 : fields) {
					Annotation an1[] = field1.getAnnotations();
					for (Annotation annotation : an1) {
						if (annotation
								.toString()
								.equals("@com.webonise.vaar.annotationinterface.GridColumn()")) {
							out.print("<td>");
							out.println("<label>" + field1.getName()
									+ "</label>");
							out.println("<input type=\"text\" value=\"\"> </br>");
							out.print("</td>");
						}
					}
				}
				out.print("</tr>");
				out.print("</table>");
				out.println("</div>");
				
			}

		} catch (IOException e) {

			e.printStackTrace();

		}*/
		return SKIP_BODY;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.jsp.tagext.BodyTagSupport#doEndTag()
	 */
	public int doEndTag() throws JspException {

		return SKIP_PAGE;
	}

	public AnnotationResolver getAnnotationResolver() {
		return annotationResolver;
	}

	public void setAnnotationResolver(AnnotationResolver annotationResolver) {
		this.annotationResolver = annotationResolver;
	}


}
