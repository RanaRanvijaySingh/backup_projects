package com.webonise.vaar.dao;


public interface VaarDao {
	
	public String search(String query); 

}
