package com.webonise.vaar.service;

import java.util.Iterator;

public class VaarServiceHelper {

	public String generateQuery(java.util.List<String> parameters,
			String classpath) throws ClassNotFoundException {
		System.out.println("\n\nHELPER : In the Generate Query.");
		System.out.println("HELPER : parameters recieved is :\t" + parameters);
		System.out.println("HELPER : classpath  recieved is :\t" + classpath);
		
		String query = "";
		query = "from " + classpath + " where ";
		int i = 0;
		for (Iterator<String> iterator = parameters.iterator(); iterator
				.hasNext(); i++) {
			String string = (String) iterator.next();
			if (i % 2 == 0 || i == 0)
				query = query + string;
			else {
				query = query + "=";
				query = query + string;
				if (i < (parameters.size() - 1))
					query = query + " " + "and" + " ";
			}
		}

		System.out.println("HELPER : String  returning  is  :\t" + query);
		return query;
	}

}
