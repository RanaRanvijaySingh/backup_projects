package com.webonise.vaar.service;

import java.util.List;

public interface VaarService {
	
	public List search(java.util.List<String> parameters,String classpath);

	public void display();

}
