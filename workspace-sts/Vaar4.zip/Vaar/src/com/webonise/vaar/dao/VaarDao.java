package com.webonise.vaar.dao;

import java.util.List;

public interface VaarDao {
	
	public List search(String query); 

}
