/**
 * 
 */
package com.webonise.vaar.user;

import com.webonise.vaar.annotationinterface.GridColumn;
import com.webonise.vaar.annotationinterface.SearchColumn;


/**
 * @author webonise
 * 
 */

public class Reflector {
    @SearchColumn(label="Id",type="Long")
    @GridColumn
	private int id;
    @SearchColumn(label="Name",type="String")
    @GridColumn
	private String name;
    @GridColumn
	private int salary;

}
