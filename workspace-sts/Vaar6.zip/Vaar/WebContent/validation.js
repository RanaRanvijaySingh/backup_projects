function validate()
{
	alert('called');
	var ele=document.getElementById('searchdiv').getElementsByTagName('input');
	var len=ele.length;
	var count=0;
	if(len==0)
	return false;
	for(var j=0;j<len;j++)
	{
		if((ele[j].value=="")==true)
			count=count+1;		
	}
	if(count>=len)
	{
		alert("Atlease one field Required");
		return false;
	}
   for(var i=0;i<len;i++)
	{
		 var type=ele[i].getAttribute('datatype');
		 if(type=="String" || type=="Long" || type=="Date")
			 {
			   if(type=="String" && ele[i].value!="")
				   {
				     var val=ele[i].value;
				     if(val.startsWith("'") && val.endsWith("'") && val.length>2)
				    	 {}
				     else
				    	 {
				    	   alert('Invalid String');
				    	   ele[i].focus();
				    	   ele[i].value=""
				    	   return false;
				    	 }
				   }
			   if(type=="Long" && ele[i].value!="")
				   {
				     var letters = /^[0-9]+$/;
				     if(!ele[i].value.match(letters))
					   {
					     alert('only numbers allowed');
					     ele[i].focus();
					     ele[i].value="";
					     return false;
					   }
				   }
			   if(type=="Date" && ele[i].value!="")
				   {
				      var matches = /^(\d{2})[-\/](\d{2})[-\/](\d{4})$/.exec(ele[i].value);
				      
				      
				      if (matches != null)
				    	  {
				    	     var d = matches[2];
					         var m = matches[1] - 1;
					         var y = matches[3];
					         var composedDate = new Date(y, m, d);
				    	     
					         if((composedDate.getDate() == d &&
					            composedDate.getMonth() == m &&
					            composedDate.getFullYear() == y))
				   		      {
				   		        return true;   
				   		      }
				    	  }
					        	    alert("Invalid Date Format(use (MM-DD-YYYY) format)");
					   		        ele[i].focus();
							        ele[i].value="";
					   		        return false;
				   }
			 }
		 else
			 {
			    alert("Annotation Specified with invalid Datatype(use String or Long or Date)");
			    return false;
			 }
			 
	}
	return true;
}