package com.webonise.vaar.dao;

import java.util.Iterator;
import java.util.List;

import javax.swing.JOptionPane;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.webonise.vaar.user.Employee;

public class VaarDaoImpl implements VaarDao{
	
	private static SessionFactory factory;
	private static Session session = null;
	 private String classpath;
	      
	public VaarDaoImpl(String classpath) {
		this.classpath=classpath;
	}

	@Override
	public List search(String query) {
		try {
			Configuration cfg = new Configuration().configure();
			factory = cfg.buildSessionFactory();
		} catch (Throwable ex) {
			System.err.println("Failed to create sessionFactory object."
					+ ex);
			throw new ExceptionInInitializerError(ex);
		}
		session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Query finalQuery = session.createQuery(query);
		
		List<Employee> list =finalQuery.list();
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			Employee employee = (Employee) iterator.next();
			JOptionPane.showMessageDialog(null, employee.getName());
		}
		transaction.commit();
	
		return list;
	}
}
