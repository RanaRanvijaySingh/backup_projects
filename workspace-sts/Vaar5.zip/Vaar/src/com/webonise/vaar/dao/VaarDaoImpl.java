package com.webonise.vaar.dao;

import java.util.Iterator;

import java.util.List;

import javax.swing.JOptionPane;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.webonise.vaar.user.Employee;

@Repository("userDao")
public class VaarDaoImpl implements VaarDao{
	

	@Autowired
	SessionFactory sessionfactory;
	
	private String classpath;
	      
	public VaarDaoImpl(String classpath) {
		this.classpath=classpath;
	}

	public List search(String query)
	{
		System.out.println("class path is : "+ classpath);
		System.out.println("the query made is : "+ query);
		
		@SuppressWarnings("unchecked")
		List<Employee> userlist = sessionfactory.getCurrentSession()
		.createCriteria(Employee.class).list();
		
		
		
		return userlist;
		
	}
}
