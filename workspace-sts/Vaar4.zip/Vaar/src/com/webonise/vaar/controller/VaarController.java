package com.webonise.vaar.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/")
public class VaarController{
 
   @RequestMapping(value = "/search",method = RequestMethod.GET)
   public String printHello(@RequestParam(value = "defination" ,defaultValue="asynchronous") final String name) {
	  
	   System.out.println("in the printhello");
	   System.out.println(name);
	   
	
	   
	   
	   //String defination = method.getMethod(defination);
	   
      //model.addAttribute("message", "Hello Spring MVC Framework!");

      return "Home";
   }

}

