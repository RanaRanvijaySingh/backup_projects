package com.webonise.vaar.dao;

import java.util.Iterator;
import java.util.List;

import javax.swing.JOptionPane;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;


import com.webonise.vaar.user.Employee;

public class VaarDaoImpl implements VaarDao{
	
	@Autowired
	SessionFactory sessionfactory;
	
	private String classpath;
	
	

	@SuppressWarnings("rawtypes")
	@Override
	public List search(String query) 
	{
		System.out.println("\n\nIn the dao ... ");
		@SuppressWarnings("unchecked")
		List<Employee> userlist = sessionfactory.getCurrentSession().createCriteria(Employee.class).list();
		
		System.out.println("ID\tNAME\t\tDEPT\tDOB");
		for (Iterator iterator = userlist.iterator(); iterator.hasNext();) 
		{
			Employee employee = (Employee) iterator.next();
			
			System.out.println(employee.getId()+"\t"+employee.getName()+"\t\t"+employee.getDepartment()+"\t"+employee.getDate());
			
			//JOptionPane.showMessageDialog(null,employee.getId()+" "+employee.getName()+" "+employee.getDate());
		}
			
			
		return userlist;
	}
	

	@Override
	public void setClassPath(String classpath) {
		this.classpath=classpath;
		
	}


	
//	@Override
//	public List search(String query) {
//		try 
//		{
//			System.out.println("\n\nIn the DAO layer...");
//			
//			Configuration cfg = new Configuration().configure();
//			factory = cfg.buildSessionFactory();
//	
//			System.out.println("Configuration and factory is set ... ");
//		}
//		catch (Throwable ex) 
//		{
//			System.err.println("Failed to create sessionFactory object."
//					+ ex);
//			throw new ExceptionInInitializerError(ex);
//		}
//		
//		session = factory.openSession();
//		System.out.println("session opened...");
//		
//		Transaction transaction = session.beginTransaction();
//		System.out.println("transaction started... ");
//		
//		Query finalQuery = session.createQuery(query);
//		System.out.println("query created...");
//		
//		List<Employee> list =finalQuery.list();
//		System.out.println("data RETRIEVED...");
//		
//		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
//			Employee employee = (Employee) iterator.next();
//			JOptionPane.showMessageDialog(null,employee.getId()+" "+employee.getName()+" "+employee.getDate());
//		}
//		
//		if(list.size()==0)
//			JOptionPane.showMessageDialog(null,"No Records Found !!!");	
//		transaction.commit();
//		System.out.println("returning the list from DataBase.");
//		return list;
//	}

}
