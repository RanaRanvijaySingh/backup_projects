package com.webonise.servletdemo.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.webonise.serveletdemo.model.Department;

/**
 * @author webonise
 * interface to be implemented by the EmplyeeSerive class
 */
public interface DepartmentServiceInterface {

	public void addIntoDepartment(Department department) throws SQLException;

	public ArrayList<Department> getServiceDepartmentData();

}
