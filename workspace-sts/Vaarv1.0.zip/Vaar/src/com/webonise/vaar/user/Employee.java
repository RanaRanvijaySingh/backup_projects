package com.webonise.vaar.user;
import java.io.Serializable;
import java.util.Date;

import com.webonise.vaar.annotationinterface.GridColumn;
import com.webonise.vaar.annotationinterface.SearchColumn;

public class Employee implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@SearchColumn
    @GridColumn
	private int Emp_id;
	@SearchColumn
    @GridColumn
	private String Emp_name;
	@GridColumn
	private int Dept_id;
	private Date dob;

	public Employee() {
	}

	public Employee(int id, String empName, int deptId) {
		this.Emp_id = id;
		this.Emp_name = empName;
		this.Dept_id = deptId;
		this.dob = null;
	}
	

	public String getEmp_name() {
		return Emp_name;
	}

	public void setEmp_name(String emp_name) {
		Emp_name = emp_name;
	}

	public int getEmp_id() {
		return Emp_id;
	}

	public void setEmp_id(int emp_id) {
		Emp_id = emp_id;
	}



	

	public int getDept_id() {
		return Dept_id;
	}

	public void setDept_id(int dept_id) {
		Dept_id = dept_id;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}
	

}
