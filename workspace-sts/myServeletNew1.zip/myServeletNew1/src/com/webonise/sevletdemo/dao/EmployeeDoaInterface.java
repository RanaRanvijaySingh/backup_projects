package com.webonise.sevletdemo.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.webonise.serveletdemo.model.Employee;

/**
 * @author webonise
 * interface to be implemented by the EmployeeImp class
 */
public interface EmployeeDoaInterface 
{
	void addEmployeeRow(Employee employee) throws SQLException;
	public ArrayList<Employee> fetchDaoEmployeeData() throws SQLException;

}
